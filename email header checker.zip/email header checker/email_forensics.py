import re
import requests

def extract_headers(raw_header):
    headers = {}
    current_key = None
    for line in raw_header.splitlines():
        if ':' in line and not line.startswith(' '):
            key, value = line.split(':', 1)
            current_key = key.strip()
            headers[current_key] = value.strip()
        elif current_key:
            headers[current_key] += ' ' + line.strip()
    return headers

def extract_sender_ip(received_header):
    ip_pattern = re.compile(r'\[?\b(?:\d{1,3}\.){3}\d{1,3}\b\]?')
    if isinstance(received_header, list):
        headers = received_header
    else:
        headers = [received_header]
    for header in headers:
        match = ip_pattern.search(header)
        if match:
            return match.group().strip("[]")
    return None

def trace_ip(ip_address):
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}")
        data = response.json()
        return {
            "IP": ip_address,
            "Country": data.get("country"),
            "Region": data.get("regionName"),
            "City": data.get("city"),
            "ISP": data.get("isp"),
            "Org": data.get("org")
        }
    except Exception as e:
        return {"Error": str(e)}

def check_phishing_keywords(email_body):
    phishing_keywords = [
        "verify your account",
        "urgent action required",
        "click here to update",
        "login immediately",
        "account suspended",
        "security alert",
        "unauthorized access",
        "reset your password",
        "confirm your identity",
        "update billing information"
    ]
    body_lower = email_body.lower()
    found = [kw for kw in phishing_keywords if kw in body_lower]
    return found

def main():
    print("\n\n🔍 Tool developed by: pradeep B wijerathna")
    print("⚙️  Powered by: Python + IP-API + Regex Analysis")
    print("📅 Year: 2025 | 🔒 Project: Email Forensics & Phishing Detection")

    
    print("\nPaste the full email header (end with '__END__'):")
    header_lines = []
    while True:
        line = input()
        if line.strip() == "__END__":
            break
        header_lines.append(line)
    raw_header = "\n".join(header_lines)

    headers = extract_headers(raw_header)

    print("\n--- Extracted Header Fields ---")
    for field in ["From", "To", "Subject", "Date", "Received", "Return-Path"]:
        if field in headers:
            print(f"{field}: {headers[field]}")

    print("\n[*] Extracting Sender IP...")
    sender_ip = extract_sender_ip(headers.get("Received", ""))
    print("Sender IP:", sender_ip if sender_ip else "Not found")

    if sender_ip:
        print("\n[*] Tracing IP...")
        ip_info = trace_ip(sender_ip)
        for key, value in ip_info.items():
            print(f"{key}: {value}")

    print("\nPaste the email body (end with '__END__') for Phishing Detection:")
    body_lines = []
    while True:
        line = input()
        if line.strip() == "__END__":
            break
        body_lines.append(line)
    email_body = "\n".join(body_lines)

    print("\n[*] Analyzing Email Body for Phishing...")
    matches = check_phishing_keywords(email_body)

    print("\n--- PHISHING CHECK RESULT ---")
    if matches:
        print("This email is likely a PHISHING attempt.")
        print("Matched keywords:", ", ".join(matches))
    else:
        print("No phishing keywords detected. Email appears safe (but manual review is advised).")

if __name__ == "__main__":
    main()

